AMERICAN DELEGATION LOGO
October 2026

WHAT'S HERE
  wordmark-on-dark     Main logo for navy or dark backgrounds.
  wordmark-on-light    Main logo for cream, white or light backgrounds.
  wordmark-white       One color, for photos and busy backgrounds.
  wordmark-navy        One color, for print and stamps.
  icon-square          Profile pictures (Instagram, TikTok, YouTube crop it to a circle).
  icon-circle          Pre-cropped circle version of the icon.
  icon-rounded         App-style icon.
  favicon (SVG only)   Browser tab. Thicker line so it holds up at 16 px.
  seal                 The badge: stickers, merch, Instagram highlight covers.
  seal-navy-one-color  The badge as a one-color stamp.

  SVG files are the masters and scale to any size. PNGs have transparent backgrounds.

THE LINE
  The stripe is split 12 : 10 : 8, the three biggest scores in Eurovision voting.
  Red is the 12 (douze points), the middle bar is the 10, blue is the 8.
  The middle bar is cream on dark backgrounds and gold on light ones.
  The stripe is always the full width of DELEGATION. Don't stretch, recolor or reorder it.

THE NAME
  The logo reads AMERICAN DELEGATION. The show is still "The American Delegation"
  everywhere it's written or said.

GIVE IT ROOM
  Keep clear space around the wordmark at least the height of the stripe times three.
  Don't put it below 120 px wide on screen; use the icon instead.

TYPE
  The letters are outlined Archivo Expanded Black (SIL Open Font License),
  so the logo never depends on a font being installed.
